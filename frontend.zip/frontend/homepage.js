document.addEventListener("DOMContentLoaded", () => {
    console.log("Homepage loaded successfully");
  });
  